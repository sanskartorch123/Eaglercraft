EAGLER 1.14.4 COMES WITH NEW FEATURES! PETS FOR YOUR PROFILE (COMING SOON) AND ABILITY TO CONNECT TO 1.14.4 SERVERS! AR-DEV-1 WILL MAKE A EAGLER WEBSOCKET FOR 1.14.4!
Debug Update: 0.1.4

you might need to reload it two times
When it gets to the press anywhere screen, click it a few times, then wait for like 15 seconds! i takes a while to load because its a bit big on the client.
